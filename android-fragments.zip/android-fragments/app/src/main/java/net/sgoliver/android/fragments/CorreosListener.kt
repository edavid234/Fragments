package net.sgoliver.android.controlpers3

import net.sgoliver.android.fragments.Correo

interface CorreosListener {
    fun onCorreoSeleccionado(correo: Correo)
}